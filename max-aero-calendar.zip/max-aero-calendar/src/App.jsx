
import React from 'react'

export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', textAlign: 'center', padding: '50px' }}>
      <h1>MAX AERO — Календар</h1>
      <p>Це базова версія для публікації на Vercel.</p>
    </div>
  )
}
